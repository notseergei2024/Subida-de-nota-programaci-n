package modelo;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public abstract class Usuario implements Serializable {
    protected int id;
    protected String nombre;
    protected List<Libro> librosPrestados = new ArrayList<>();

    public Usuario(int id, String nombre) {
        this.id = id;
        this.nombre = nombre;
    }

    public abstract double calcularMulta(int diasRetraso);
    public abstract int getLimitePrestamos();

    public boolean puedePrestar() {
        return librosPrestados.size() < getLimitePrestamos();
    }

    public void prestarLibro(Libro libro) {
        librosPrestados.add(libro);
    }

    public int getId() { return id; }
    public String getNombre() { return nombre; }
}
