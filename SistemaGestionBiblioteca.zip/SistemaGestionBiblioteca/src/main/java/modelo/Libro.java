package modelo;

import java.io.Serializable;

public abstract class Libro implements Serializable {
    protected String isbn;
    protected String titulo;
    protected String autor;
    protected boolean disponible = true;

    public Libro(String isbn, String titulo, String autor) {
        this.isbn = isbn;
        this.titulo = titulo;
        this.autor = autor;
    }

    public String getIsbn() { return isbn; }
    public String getTitulo() { return titulo; }
    public String getAutor() { return autor; }
    public boolean isDisponible() { return disponible; }
    public void setDisponible(boolean disponible) { this.disponible = disponible; }

    public abstract String getTipo();
}
