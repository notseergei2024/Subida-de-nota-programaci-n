package modelo;

public class Estudiante extends Usuario {
    public Estudiante(int id, String nombre) {
        super(id, nombre);
    }

    @Override
    public double calcularMulta(int diasRetraso) {
        return diasRetraso * 0.50;
    }

    @Override
    public int getLimitePrestamos() {
        return 3;
    }
}
