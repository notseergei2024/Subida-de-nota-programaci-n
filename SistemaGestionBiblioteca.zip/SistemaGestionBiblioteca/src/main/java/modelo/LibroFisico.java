package modelo;

public class LibroFisico extends Libro {
    private String ubicacionEstante;

    public LibroFisico(String isbn, String titulo, String autor, String ubicacionEstante) {
        super(isbn, titulo, autor);
        this.ubicacionEstante = ubicacionEstante;
    }

    @Override
    public String getTipo() {
        return "Físico";
    }

    public String getUbicacionEstante() {
        return ubicacionEstante;
    }
}
