package modelo;

public class Profesor extends Usuario {
    public Profesor(int id, String nombre) {
        super(id, nombre);
    }

    @Override
    public double calcularMulta(int diasRetraso) {
        return diasRetraso * 0.25;
    }

    @Override
    public int getLimitePrestamos() {
        return 5;
    }
}
