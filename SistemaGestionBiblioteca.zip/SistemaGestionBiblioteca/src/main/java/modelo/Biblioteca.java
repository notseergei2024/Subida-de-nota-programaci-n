package modelo;

import excepciones.*;

import java.io.*;
import java.util.*;

public class Biblioteca implements Serializable {
    private static final long serialVersionUID = 1L;

    private static Biblioteca instancia;
    private Map<String, Libro> libros = new HashMap<>();
    private Map<Integer, Usuario> usuarios = new HashMap<>();

    private Biblioteca() {}

    public static Biblioteca getInstancia() {
        if (instancia == null) instancia = new Biblioteca();
        return instancia;
    }

    // Registro de libros
    public void registrarLibro(Libro libro) throws ISBNException {
        if (libros.containsKey(libro.getIsbn()))
            throw new ISBNException("ISBN ya registrado");
        libros.put(libro.getIsbn(), libro);
    }

    // Registro de usuarios
    public void registrarUsuario(Usuario usuario) {
        usuarios.put(usuario.getId(), usuario);
    }

    // Préstamo
    public void realizarPrestamo(int userId, String isbn) throws BibliotecaException {
        Usuario usuario = usuarios.get(userId);
        Libro libro = libros.get(isbn);

        if (usuario == null || libro == null)
            throw new PrestamoException("Usuario o libro no encontrado");
        if (!libro.isDisponible())
            throw new PrestamoException("Libro no disponible");
        if (!usuario.puedePrestar()) {
            if (usuario instanceof Profesor)
                throw new ProfesorNoPuedePrestarException("Profesor excede el límite de préstamos");
            else
                throw new PrestamoException("Límite de préstamos alcanzado");
        }

        usuario.prestarLibro(libro);
        libro.setDisponible(false);
    }

    // Guardar datos
    public void guardar(String ruta) throws PersistenciaException {
        try (ObjectOutputStream out = new ObjectOutputStream(new FileOutputStream(ruta))) {
            out.writeObject(instancia);
        } catch (IOException e) {
            throw new PersistenciaException("Error al guardar datos: " + e.getMessage());
        }
    }

    // Cargar datos
    public static void cargar(String ruta) throws PersistenciaException {
        try (ObjectInputStream in = new ObjectInputStream(new FileInputStream(ruta))) {
            instancia = (Biblioteca) in.readObject();
        } catch (IOException | ClassNotFoundException e) {
            throw new PersistenciaException("Error al cargar datos: " + e.getMessage());
        }
    }

    // ✅ Métodos de búsqueda

    public Libro buscarLibroPorISBN(String isbn) throws LibroNoEncontradoException {
        Libro libro = libros.get(isbn);
        if (libro == null) throw new LibroNoEncontradoException("No se encontró un libro con ISBN " + isbn);
        return libro;
    }

    public List<Libro> buscarLibrosPorTitulo(String titulo) throws LibroNoEncontradoException {
        List<Libro> resultados = new ArrayList<>();
        for (Libro l : libros.values()) {
            if (l.getTitulo().equalsIgnoreCase(titulo)) {
                resultados.add(l);
            }
        }
        if (resultados.isEmpty()) throw new LibroNoEncontradoException("No se encontraron libros con ese título.");
        return resultados;
    }

    public List<Libro> buscarLibrosPorAutor(String autor) throws LibroNoEncontradoException {
        List<Libro> resultados = new ArrayList<>();
        for (Libro l : libros.values()) {
            if (l.getAutor().equalsIgnoreCase(autor)) {
                resultados.add(l);
            }
        }
        if (resultados.isEmpty()) throw new LibroNoEncontradoException("No se encontraron libros de ese autor.");
        return resultados;
    }

    // ✅ Métodos de utilidad
    public Collection<Libro> getLibros() {
        return libros.values();
    }

    public Collection<Usuario> getUsuarios() {
        return usuarios.values();
    }
}
