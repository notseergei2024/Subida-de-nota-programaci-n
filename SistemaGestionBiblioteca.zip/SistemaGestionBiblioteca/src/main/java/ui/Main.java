package ui;

import javax.swing.SwingUtilities;
import modelo.Biblioteca;
import excepciones.PersistenciaException;
import utils.Logger;

public class Main {
    public static void main(String[] args) {
        // Cargar datos al iniciar
        try {
            Biblioteca.cargar("biblioteca.dat");
        } catch (PersistenciaException e) {
            Logger.registrarError(e.getMessage());
        }

        // Lanzar la interfaz Swing
        SwingUtilities.invokeLater(() -> {
            new BibliotecaGUI().setVisible(true);
        });

        // Guardar datos al cerrar
        Runtime.getRuntime().addShutdownHook(new Thread(() -> {
            try {
                Biblioteca.getInstancia().guardar("biblioteca.dat");
            } catch (PersistenciaException e) {
                Logger.registrarError(e.getMessage());
            }
        }));
    }
}

