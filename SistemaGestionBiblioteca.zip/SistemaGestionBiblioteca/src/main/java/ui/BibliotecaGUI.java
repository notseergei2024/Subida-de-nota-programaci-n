package ui;

import modelo.*;
import excepciones.*;
import utils.Logger;

import javax.swing.*;
import java.awt.*;
import java.util.List;

public class BibliotecaGUI extends JFrame {
    private final Biblioteca biblioteca = Biblioteca.getInstancia();

    public BibliotecaGUI() {
        setTitle("Sistema de Gestión de Biblioteca");
        setSize(600, 500);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        JTabbedPane tabs = new JTabbedPane();
        tabs.add("Registrar Libro", panelRegistrarLibro());
        tabs.add("Registrar Usuario", panelRegistrarUsuario());
        tabs.add("Realizar Préstamo", panelPrestamo());
        tabs.add("Buscar Libro", panelBuscarLibro());

        add(tabs);
    }

    private JPanel panelRegistrarLibro() {
        JPanel panel = new JPanel(new GridLayout(6, 2));
        JTextField isbnField = new JTextField();
        JTextField tituloField = new JTextField();
        JTextField autorField = new JTextField();
        JComboBox<String> tipoBox = new JComboBox<>(new String[]{"Físico", "Digital"});
        JTextField extraField = new JTextField(); // estante o URL

        JButton registrarBtn = new JButton("Registrar");
        registrarBtn.addActionListener(e -> {
            try {
                String isbn = isbnField.getText().trim();
                String titulo = tituloField.getText().trim();
                String autor = autorField.getText().trim();
                String tipo = (String) tipoBox.getSelectedItem();
                String extra = extraField.getText().trim();

                Libro libro;
                if ("Físico".equals(tipo)) {
                    libro = new LibroFisico(isbn, titulo, autor, extra);
                } else {
                    libro = new LibroDigital(isbn, titulo, autor, extra);
                }

                biblioteca.registrarLibro(libro);
                JOptionPane.showMessageDialog(this, "Libro registrado correctamente.");
            } catch (BibliotecaException ex) {
                Logger.registrarError(ex.getMessage());
                JOptionPane.showMessageDialog(this, "Error: " + ex.getMessage());
            }
        });

        panel.add(new JLabel("ISBN:"));
        panel.add(isbnField);
        panel.add(new JLabel("Título:"));
        panel.add(tituloField);
        panel.add(new JLabel("Autor:"));
        panel.add(autorField);
        panel.add(new JLabel("Tipo:"));
        panel.add(tipoBox);
        panel.add(new JLabel("Estante o URL:"));
        panel.add(extraField);
        panel.add(new JLabel());
        panel.add(registrarBtn);

        return panel;
    }

    private JPanel panelRegistrarUsuario() {
        JPanel panel = new JPanel(new GridLayout(4, 2));
        JTextField idField = new JTextField();
        JTextField nombreField = new JTextField();
        JComboBox<String> tipoBox = new JComboBox<>(new String[]{"Estudiante", "Profesor"});

        JButton registrarBtn = new JButton("Registrar");
        registrarBtn.addActionListener(e -> {
            try {
                int id = Integer.parseInt(idField.getText().trim());
                String nombre = nombreField.getText().trim();
                Usuario usuario = "Estudiante".equals(tipoBox.getSelectedItem())
                        ? new Estudiante(id, nombre)
                        : new Profesor(id, nombre);

                biblioteca.registrarUsuario(usuario);
                JOptionPane.showMessageDialog(this, "Usuario registrado correctamente.");
            } catch (Exception ex) {
                Logger.registrarError(ex.getMessage());
                JOptionPane.showMessageDialog(this, "Error: " + ex.getMessage());
            }
        });

        panel.add(new JLabel("ID:"));
        panel.add(idField);
        panel.add(new JLabel("Nombre:"));
        panel.add(nombreField);
        panel.add(new JLabel("Tipo:"));
        panel.add(tipoBox);
        panel.add(new JLabel());
        panel.add(registrarBtn);

        return panel;
    }

    private JPanel panelPrestamo() {
        JPanel panel = new JPanel(new GridLayout(3, 2));
        JTextField idUsuario = new JTextField();
        JTextField isbnLibro = new JTextField();

        JButton prestarBtn = new JButton("Prestar");
        prestarBtn.addActionListener(e -> {
            try {
                int id = Integer.parseInt(idUsuario.getText().trim());
                String isbn = isbnLibro.getText().trim();
                biblioteca.realizarPrestamo(id, isbn);
                JOptionPane.showMessageDialog(this, "Préstamo realizado correctamente.");
            } catch (BibliotecaException ex) {
                Logger.registrarError(ex.getMessage());
                JOptionPane.showMessageDialog(this, "Error: " + ex.getMessage());
            }
        });

        panel.add(new JLabel("ID Usuario:"));
        panel.add(idUsuario);
        panel.add(new JLabel("ISBN Libro:"));
        panel.add(isbnLibro);
        panel.add(new JLabel());
        panel.add(prestarBtn);

        return panel;
    }

    private JPanel panelBuscarLibro() {
        JPanel panel = new JPanel(new BorderLayout());

        JPanel topPanel = new JPanel(new GridLayout(3, 2));
        JComboBox<String> criterioBox = new JComboBox<>(new String[]{"ISBN", "Título", "Autor"});
        JTextField valorField = new JTextField();
        JTextArea resultadoArea = new JTextArea(8, 30);
        resultadoArea.setEditable(false);

        JButton buscarBtn = new JButton("Buscar");
        buscarBtn.addActionListener(e -> {
            resultadoArea.setText("");
            String criterio = (String) criterioBox.getSelectedItem();
            String valor = valorField.getText().trim();

            try {
                if ("ISBN".equals(criterio)) {
                    Libro libro = biblioteca.buscarLibroPorISBN(valor);
                    resultadoArea.setText(formatoLibro(libro));
                } else if ("Título".equals(criterio)) {
                    List<Libro> libros = biblioteca.buscarLibrosPorTitulo(valor);
                    libros.forEach(l -> resultadoArea.append(formatoLibro(l) + "\n"));
                } else {
                    List<Libro> libros = biblioteca.buscarLibrosPorAutor(valor);
                    libros.forEach(l -> resultadoArea.append(formatoLibro(l) + "\n"));
                }
            } catch (BibliotecaException ex) {
                Logger.registrarError(ex.getMessage());
                JOptionPane.showMessageDialog(this, "Error: " + ex.getMessage());
            }
        });

        topPanel.add(new JLabel("Buscar por:"));
        topPanel.add(criterioBox);
        topPanel.add(new JLabel("Valor:"));
        topPanel.add(valorField);
        topPanel.add(new JLabel());
        topPanel.add(buscarBtn);

        panel.add(topPanel, BorderLayout.NORTH);
        panel.add(new JScrollPane(resultadoArea), BorderLayout.CENTER);

        return panel;
    }

    private String formatoLibro(Libro libro) {
        return libro.getTipo() + ": " + libro.getTitulo() + " (" + libro.getAutor() + "), ISBN: " + libro.getIsbn();
    }
}
