package utils;

import java.io.FileWriter;
import java.io.PrintWriter;
import java.time.LocalDateTime;

public class Logger {
    public static void registrarError(String mensaje) {
        try (PrintWriter out = new PrintWriter(new FileWriter("log.txt", true))) {
            out.println(LocalDateTime.now() + ": " + mensaje);
        } catch (Exception e) {
            System.err.println("No se pudo registrar el error");
        }
    }
}
