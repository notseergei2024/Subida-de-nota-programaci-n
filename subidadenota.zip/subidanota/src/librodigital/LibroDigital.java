package librodigital;

import libro.Libro;

public class LibroDigital extends Libro {
    private String url;

    public LibroDigital(String isbn, String titulo, String autor, String url) {
        super(isbn, titulo, autor);
        this.url = url;
    }

    @Override
    public String getTipo() {
        return "Digital";
    }
} 
