package estudiante;

import usuario.Usuario;

public class Estudiante extends Usuario {
    public Estudiante(int id, String nombre) {
        super(id, nombre);
    }

    @Override
    public double calcularMulta(int dias) {
        return dias * 0.50;
    }
} 
