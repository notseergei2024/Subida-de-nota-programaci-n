package Biblioteca;

import libro.Libro;
import com.google.gson.*;
import java.io.*;
import java.util.*;
import usuario.Usuario;
import excepciones.ISBNException;
import excepciones.BibliotecaException;
import excepciones.PersistenciaException;

public class Biblioteca implements Serializable {
    private static Biblioteca instancia;
    private List<Libro> libros;
    private List<Usuario> usuarios;
    private static final String ARCHIVO_JSON = "biblioteca.json";

    private Biblioteca() {
        libros = new ArrayList<>();
        usuarios = new ArrayList<>();
    }

    public static Biblioteca getInstancia() {
        if (instancia == null) {
            instancia = new Biblioteca();
        }
        return instancia;
    }

    public void registrarLibro(Libro libro) throws ISBNException {
        for (Libro l : libros) {
        	if (l.getIsbn().equals(libro.getIsbn())) {

                throw new ISBNException("ISBN ya registrado");
            }
        }
        libros.add(libro);
    }

    public void registrarUsuario(Usuario usuario) {
        usuarios.add(usuario);
    }

    public void guardar() throws PersistenciaException {
        try (Writer writer = new FileWriter(ARCHIVO_JSON)) {
            Gson gson = new Gson();
            gson.toJson(this, writer);
        } catch (IOException e) {
            throw new PersistenciaException("Error guardando datos");
        }
    }

    public static void cargar() throws PersistenciaException {
        try (Reader reader = new FileReader(ARCHIVO_JSON)) {
            Gson gson = new Gson();
            instancia = gson.fromJson(reader, Biblioteca.class);
        } catch (IOException e) {
            throw new PersistenciaException("Error cargando datos");
        }
    }
} 

