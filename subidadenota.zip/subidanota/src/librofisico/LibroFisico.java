package librofisico;

import libro.*;
import java.util.logging.Logger;

public class LibroFisico extends Libro {
    private String ubicacionEstante;
    private static final Logger logger = Logger.getLogger(LibroFisico.class.getName());

    public LibroFisico(String isbn, String titulo, String autor, String ubicacionEstante) {
        super(isbn, titulo, autor);
        this.ubicacionEstante = ubicacionEstante;
    }

    @Override
    public String getTipo() {
        return "Físico";
    }
} 
