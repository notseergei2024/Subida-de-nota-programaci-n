package libro;

import java.io.Serializable;

public abstract class Libro implements Serializable {
    protected String isbn;
    protected String titulo;
    protected String autor;
    protected boolean disponible;

    public Libro(String isbn, String titulo, String autor) {
        this.isbn = isbn;
        this.titulo = titulo;
        this.autor = autor;
        this.disponible = true;
    }
    
    public String getIsbn() {
        return isbn;
    }

    public abstract String getTipo();

    public boolean isDisponible() {
        return disponible;
    }

    public void setDisponible(boolean disponible) {
        this.disponible = disponible;
    }
} 
