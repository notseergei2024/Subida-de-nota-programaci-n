package usuario;

import java.io.Serializable;

public abstract class Usuario implements Serializable {
    protected int id;
    protected String nombre;
    protected int librosPrestados;

    public Usuario(int id, String nombre) {
        this.id = id;
        this.nombre = nombre;
        this.librosPrestados = 0;
    }

    public abstract double calcularMulta(int dias);

    public int getLibrosPrestados() {
        return librosPrestados;
    }

    public void prestarLibro() {
        librosPrestados++;
    }

    public void devolverLibro() {
        librosPrestados--;
    }
} 
