package excepciones;

class PrestamoException extends BibliotecaException {
    public PrestamoException(String mensaje) {
        super(mensaje);
    }
}