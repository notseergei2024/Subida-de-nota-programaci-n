package excepciones;

class ProfesorNoPuedePrestarException extends PrestamoException {
    public ProfesorNoPuedePrestarException() {
        super("El profesor ha superado el límite de 5 préstamos.");
    }
} 
