/**
 * 
 */
/**
 * 
 */
module subidanota {
    requires com.google.gson;
    requires java.logging;
}
