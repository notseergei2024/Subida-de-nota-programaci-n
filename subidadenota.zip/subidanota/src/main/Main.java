package main;

import Biblioteca.Biblioteca;
import excepciones.*;

import librofisico.LibroFisico;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Biblioteca bib = Biblioteca.getInstancia();
        Scanner sc = new Scanner(System.in);

        try {
            Biblioteca.cargar();
        } catch (PersistenciaException e) {
            System.out.println("No se pudo cargar la base de datos.");
        }

        while (true) {
            System.out.println("1. Registrar Libro\n2. Salir");
            int opc = Integer.parseInt(sc.nextLine());
            if (opc == 1) {
                try {
                    System.out.print("ISBN: ");
                    String isbn = sc.nextLine();
                    System.out.print("Título: ");
                    String titulo = sc.nextLine();
                    System.out.print("Autor: ");
                    String autor = sc.nextLine();
                    System.out.print("Estante: ");
                    String estante = sc.nextLine();
                    bib.registrarLibro(new LibroFisico(isbn, titulo, autor, estante));
                    System.out.println("Libro registrado.");
                } catch (BibliotecaException e) {
                    System.out.println("Error: " + e.getMessage());
                }
            } else {
                break;
            }
        }

        try {
            bib.guardar();
        } catch (PersistenciaException e) {
            System.out.println("Error al guardar: " + e.getMessage());
        }
    }
} 
